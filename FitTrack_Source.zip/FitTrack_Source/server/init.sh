python3 -m venv venv
venv/bin/pip3 install -r requirements.txt
venv/bin/alembic upgrade head
